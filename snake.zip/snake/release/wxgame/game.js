require("weapp-adapter.js");
window.p2 = require('p2.min.js');
require("./code.js");
require('utils.min.js');